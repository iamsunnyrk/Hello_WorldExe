name = input("Enter your name: ")
print("Hello ", name )
enter = input("Press any key to exit!!!")
